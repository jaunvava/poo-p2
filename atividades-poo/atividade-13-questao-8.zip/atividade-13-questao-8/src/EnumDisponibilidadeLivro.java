public enum EnumDisponibilidadeLivro {
    DISPONIVEL, EMPRESTADO, RESERVADO
}
